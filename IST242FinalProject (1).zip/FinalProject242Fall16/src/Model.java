
import java.awt.Color;
import java.util.Timer;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Master
 */
public class Model {
    
    
    
    Model(){
        
        //time = new javax.swing.Timer(10,);
//        enemy1 = new TangibleObject(55,20,10,10);
//        enemy2 = new TangibleObject(300,11,10,10);
//        enemy3 = new TangibleObject(300,300,10,10);
//        enemy4 = new TangibleObject(350,300,10,10);
        
        
    }
    
}
