
import java.awt.event.ActionEvent;
import java.util.Timer;

public class Controller {
    
    private Timer time;
    
    Controller(Model model,View view){
        
        
    }
    

}
